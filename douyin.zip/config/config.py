#!/usr/bin/python
# coding:utf-8

# 系统配置
class Config:
    # 监控的直播间ID列表
    MONITOR_ROOMS = [
        '123456', # 直播间ID

    ]
    
    # 直播间ID和昵称的映射
    ROOM_NAMES = {
        '123456': '测试',  # 示例：直播间ID -> 昵称
    }
    
    # 监控的用户ID列表
    MONITOR_USERS = [
        '123456',  # 用户ID
         
    ]
    
    # 日志配置
    LOG_LEVEL = 'DEBUG'
    LOG_FILE = 'monitor.log'
    
    # WebSocket配置
    WS_RECONNECT_INTERVAL = 5  # 重连间隔（秒）
    WS_HEARTBEAT_INTERVAL = 30  # 心跳间隔（秒）
    
    # 通知配置
    NOTIFY_CONFIG = {
        'enable_weibo': True,  # 是否启用微博通知
        'enable_wx': True,  # 是否启用微信通知
        'enable_wework': True,  # 是否启用企业微信通知
        'notify_cooldown': 1  # 通知冷却时间（秒）
    }
    
    # 企业微信配置
    WEWORK_CONFIG = {
        'corp_id': '123',  # 企业ID
        'agent_id': '123',  # 应用ID
        'secret': '123',  # 应用Secret
        'to_user': '@all'  # 接收消息的用户，@all表示所有人
    }
    
    # 微信群配置
    WX_GROUP_NAME = "测试"  # 要发送通知的微信群名称 