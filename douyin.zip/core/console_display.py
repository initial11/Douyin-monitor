import time
from datetime import datetime
from colorama import init, Fore, Style

class ConsoleDisplay:
    def __init__(self):
        init()  # 初始化colorama
        self.logger = None
        
    def set_logger(self, logger):
        """设置logger"""
        self.logger = logger
        
    def _print_with_time(self, message, color=Fore.WHITE):
        """打印带时间戳的消息"""
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"{Fore.CYAN}[{current_time}] {color}{message}{Style.RESET_ALL}")
        
    def show_user_message(self, nickname, room_name, content):
        """显示用户发送的消息"""
        self._print_with_time(f"{Fore.GREEN}消息通知{Style.RESET_ALL}")
        self._print_with_time(f"用户: {Fore.YELLOW}{nickname}{Style.RESET_ALL}")
        self._print_with_time(f"直播间: {Fore.YELLOW}{room_name}{Style.RESET_ALL}")
        self._print_with_time(f"内容: {Fore.WHITE}{content}{Style.RESET_ALL}")
        print("-" * 50)
        
    def show_user_enter(self, nickname, room_name):
        """显示用户进入直播间"""
        self._print_with_time(f"{Fore.BLUE}进入直播间通知{Style.RESET_ALL}")
        self._print_with_time(f"用户: {Fore.YELLOW}{nickname}{Style.RESET_ALL}")
        self._print_with_time(f"直播间: {Fore.YELLOW}{room_name}{Style.RESET_ALL}")
        print("-" * 50)
        
    def show_user_gift(self, nickname, room_name, gift_name, combo_count):
        """显示用户发送礼物"""
        self._print_with_time(f"{Fore.MAGENTA}礼物通知{Style.RESET_ALL}")
        self._print_with_time(f"用户: {Fore.YELLOW}{nickname}{Style.RESET_ALL}")
        self._print_with_time(f"直播间: {Fore.YELLOW}{room_name}{Style.RESET_ALL}")
        self._print_with_time(f"礼物: {Fore.RED}{gift_name}{Style.RESET_ALL}")
        self._print_with_time(f"连击数: {Fore.YELLOW}{combo_count}{Style.RESET_ALL}")
        print("-" * 50)
        
    def show_user_link(self, nickname, room_name):
        """显示用户发起连麦"""
        self._print_with_time(f"{Fore.CYAN}连麦通知{Style.RESET_ALL}")
        self._print_with_time(f"用户: {Fore.YELLOW}{nickname}{Style.RESET_ALL}")
        self._print_with_time(f"直播间: {Fore.YELLOW}{room_name}{Style.RESET_ALL}")
        print("-" * 50)
        
    def show_live_start(self, nickname, room_id):
        """显示直播间开播"""
        self._print_with_time(f"{Fore.RED}开播通知{Style.RESET_ALL}")
        self._print_with_time(f"主播: {Fore.YELLOW}{nickname}{Style.RESET_ALL}")
        self._print_with_time(f"直播间ID: {Fore.YELLOW}{room_id}{Style.RESET_ALL}")
        print("-" * 50)
        
    def show_error(self, message):
        """显示错误信息"""
        self._print_with_time(f"{Fore.RED}错误: {message}{Style.RESET_ALL}")
        print("-" * 50)
        
    def show_info(self, message):
        """显示普通信息"""
        self._print_with_time(f"{Fore.WHITE}{message}{Style.RESET_ALL}")
        print("-" * 50) 