#!/usr/bin/python
# coding:utf-8

import json
import time
import logging
import gzip
import requests
import random
from config.config import Config
from core.wx_notify import WxNotifier
from core.wework_notify import WeworkNotifier
from liveMan import DouyinLiveWebFetcher
from protobuf.douyin import ChatMessage, MemberMessage, GiftMessage, ControlMessage, PushFrame, Response, LinkMicMessage
from core.console_display import ConsoleDisplay

class LiveMonitor:
    def __init__(self, room_id):
        self.room_id = room_id
        self.room_name = None
        self.is_running = False
        self.wx_notifier = WxNotifier()
        self.wework_notifier = WeworkNotifier()
        self.logger = logging.getLogger(__name__)
        self.console = ConsoleDisplay()  # 添加控制台显示
        self.console.set_logger(self.logger)  # 设置logger
        self.live_fetcher = DouyinLiveWebFetcher(room_id)
        
        # 设置通知日志
        self.notify_logger = logging.getLogger('notify')
        self.notify_logger.setLevel(logging.INFO)
        notify_handler = logging.FileHandler('notify.log', encoding='utf-8')
        notify_handler.setLevel(logging.INFO)
        notify_formatter = logging.Formatter('%(asctime)s - %(message)s')
        notify_handler.setFormatter(notify_formatter)
        self.notify_logger.addHandler(notify_handler)
        
        # 消息去重集合
        self.processed_messages = set()
        # 通知记录去重集合
        self.notified_messages = set()
        # 通知时间窗口（秒）
        self.notify_window = 5
        # 通知时间记录
        self.notify_times = {}
        
        # 保存原始的消息处理方法
        self._original_message_handler = self.live_fetcher._wsOnMessage
        
        # 重写原项目的WebSocket回调函数
        self.live_fetcher._wsOnMessage = self._on_message
        self.live_fetcher._wsOnError = self._on_error
        self.live_fetcher._wsOnClose = self._on_close
        self.live_fetcher._wsOnOpen = self._on_open
        
        # 用户开播状态记录
        self.user_live_status = {}
        
        # 重连相关参数
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 10
        self.base_reconnect_delay = Config.WS_RECONNECT_INTERVAL
        
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        self.last_check_time = {}
        self.last_notify_time = {}
        self.room_info_cache = {}
        self.room_info_cache_time = {}
        self.room_info_cache_duration = 300  # 5分钟缓存
        
    def _should_notify(self, message_id, notification_type):
        """检查是否应该发送通知"""
        current_time = time.time()
        
        # 检查消息是否已经通知过
        if message_id in self.notified_messages:
            return False
            
        # 检查时间窗口
        if notification_type in self.notify_times:
            last_time = self.notify_times[notification_type]
            if current_time - last_time < self.notify_window:
                return False
                
        # 更新通知时间和记录
        self.notify_times[notification_type] = current_time
        self.notified_messages.add(message_id)
        
        # 限制通知记录集合的大小
        if len(self.notified_messages) > 1000:
            self.notified_messages.clear()
            self.logger.info("已清空通知记录集合")
            
        return True

    def _log_notification(self, notification_type, content, message_id):
        """记录通知日志"""
        try:
            if self._should_notify(message_id, notification_type):
                self.notify_logger.info(f"[{notification_type}] {content}")
        except Exception as e:
            self.logger.error(f"记录通知日志失败: {e}")

    def _on_message(self, ws, message):
        """处理WebSocket消息"""
        try:
            # 先解析消息
            package = PushFrame().parse(message)
            response = Response().parse(gzip.decompress(package.payload))
            
            # 过滤掉不需要的消息类型
            filtered_messages = []
            ignore_methods = [
                'WebcastRankMessage',
                'WebcastRankUpdateMessage',
                'WebcastRankUserMessage',
                'WebcastRankUserUpdateMessage',
                'WebcastRankUserEnterMessage',
                'WebcastRankUserLeaveMessage',
                'WebcastRankUserFollowMessage',
                'WebcastRankUserUnfollowMessage',
                'WebcastRankUserLikeMessage',
                'WebcastRankUserUnlikeMessage',
                'WebcastRankUserShareMessage',
                'WebcastRankUserCommentMessage',
                'WebcastRankUserGiftMessage',
                'WebcastRankUserEnterRoomMessage',
                'WebcastRankUserLeaveRoomMessage',
                'WebcastRankUserFollowRoomMessage',
                'WebcastRankUserUnfollowRoomMessage',
                'WebcastRankUserLikeRoomMessage',
                'WebcastRankUserUnlikeRoomMessage',
                'WebcastRankUserShareRoomMessage',
                'WebcastRankUserCommentRoomMessage',
                'WebcastRankUserGiftRoomMessage',
                'WebcastRankUserEnterRoomMessage',
                'WebcastRankUserLeaveRoomMessage',
                'WebcastRankUserFollowRoomMessage',
                'WebcastRankUserUnfollowRoomMessage',
                'WebcastRankUserLikeRoomMessage',
                'WebcastRankUserUnlikeRoomMessage',
                'WebcastRankUserShareRoomMessage',
                'WebcastRankUserCommentRoomMessage',
                'WebcastRankUserGiftRoomMessage',
                'WebcastRankUserEnterRoomMessage',
                'WebcastRankUserLeaveRoomMessage',
                'WebcastRankUserFollowRoomMessage',
                'WebcastRankUserUnfollowRoomMessage',
                'WebcastRankUserLikeRoomMessage',
                'WebcastRankUserUnlikeRoomMessage',
                'WebcastRankUserShareRoomMessage',
                'WebcastRankUserCommentRoomMessage',
                'WebcastRankUserGiftRoomMessage'
            ]
            
            # 只保留需要处理的消息类型
            allowed_methods = [
                'WebcastChatMessage',
                'WebcastMemberMessage',
                'WebcastGiftMessage',
                'WebcastControlMessage',
                'WebcastLinkMicMessage'
            ]
            
            for msg in response.messages_list:
                if msg.method in allowed_methods:
                    filtered_messages.append(msg)
            
            # 更新消息列表
            response.messages_list = filtered_messages
            
            # 重新打包消息
            new_message = gzip.compress(response.SerializeToString())
            package.payload = new_message
            
            # 调用原始的消息处理方法
            self._original_message_handler(ws, package.SerializeToString())
            
            # 然后处理需要通知的消息
            try:
                # 处理消息
                for msg in filtered_messages:
                    method = msg.method
                    try:
                        self._process_message(method, msg.payload)
                    except Exception as e:
                        self.logger.error(f"处理消息失败: {e}")
                        
            except Exception as e:
                # 忽略非 protobuf 消息的错误
                pass
                
        except Exception as e:
            self.logger.error(f"处理消息失败: {e}")
            
    def _on_error(self, ws, error):
        """处理WebSocket错误"""
        self.logger.error(f"WebSocket错误: {error}")
        
    def _on_close(self, ws, close_status_code, close_msg):
        """处理WebSocket关闭"""
        self.logger.info(f"WebSocket连接关闭: {close_status_code} - {close_msg}")
        self.is_running = False
        
    def _on_open(self, ws):
        """处理WebSocket连接打开"""
        self.logger.info(f"WebSocket连接已打开 - 直播间: {self.room_id}")
        self.is_running = True
        
    def _get_message_id(self, method, payload):
        """生成消息唯一ID"""
        try:
            if method == 'WebcastChatMessage':
                message = ChatMessage().parse(payload)
                # 使用用户ID、消息内容和时间戳作为唯一标识
                return f"{method}_{message.user.id}_{message.content}_{int(time.time())}"
            elif method == 'WebcastMemberMessage':
                message = MemberMessage().parse(payload)
                # 使用用户ID和时间戳作为唯一标识
                return f"{method}_{message.user.id}_{int(time.time())}"
            elif method == 'WebcastGiftMessage':
                message = GiftMessage().parse(payload)
                # 使用用户ID、礼物ID、礼物数量和时间戳作为唯一标识
                return f"{method}_{message.user.id}_{message.gift.id}_{message.combo_count}_{int(time.time())}"
            elif method == 'WebcastLinkMicMessage':
                message = LinkMicMessage().parse(payload)
                # 使用用户ID和时间戳作为唯一标识
                return f"{method}_{message.user.id}_{int(time.time())}"
            else:
                # 对于其他类型的消息，使用消息类型和payload的哈希值
                return f"{method}_{hash(payload)}"
        except Exception as e:
            self.logger.error(f"生成消息ID失败: {e}")
            # 如果解析失败，使用消息类型和payload的哈希值作为备选方案
            return f"{method}_{hash(payload)}"

    def _process_message(self, method, payload):
        """处理消息"""
        try:
            # 过滤掉所有排行榜相关的消息
            if method.startswith('WebcastRank'):
                return
                
            # 生成消息ID并检查是否已处理
            message_id = self._get_message_id(method, payload)
            
            # 检查消息是否在最近处理的消息中
            if message_id in self.processed_messages:
                self.logger.debug(f"消息已处理，跳过: {message_id}")
                return
                
            # 将消息ID添加到已处理集合
            self.processed_messages.add(message_id)
            
            # 限制已处理消息集合的大小，防止内存占用过大
            if len(self.processed_messages) > 1000:
                self.processed_messages.clear()
                self.logger.info("已清空消息去重集合")
                
            # 记录消息处理
            self.logger.debug(f"处理新消息: {message_id}")
            
            if method == 'WebcastChatMessage':
                # 聊天消息
                message = ChatMessage().parse(payload)
                user_id = str(message.user.id)
                
                # 检查是否是监控的用户
                if user_id in Config.MONITOR_USERS:
                    self.logger.info(f"监控用户发送消息 - 用户ID: {user_id}")
                    # 显示在控制台
                    self.console.show_user_message(
                        message.user.nick_name,
                        self.room_name,
                        message.content
                    )
                    # 发送通知
                    if Config.NOTIFY_CONFIG['enable_wx']:
                        self.wx_notifier.notify_user_message(
                            message.user.nick_name,
                            self.room_name,
                            message.content
                        )
                        self._log_notification("聊天消息", f"用户 {message.user.nick_name} 在直播间 {self.room_name} 发送消息: {message.content}", message_id)
                    if Config.NOTIFY_CONFIG['enable_wework']:
                        self.wework_notifier.notify_user_message(
                            message.user.nick_name,
                            self.room_name,
                            message.content
                        )
                    
            elif method == 'WebcastMemberMessage':
                # 进入直播间消息
                message = MemberMessage().parse(payload)
                user_id = str(message.user.id)
                
                # 检查是否是监控的用户
                if user_id in Config.MONITOR_USERS:
                    self.logger.info(f"监控用户进入直播间 - 用户ID: {user_id}")
                    # 显示在控制台
                    self.console.show_user_enter(
                        message.user.nick_name,
                        self.room_name
                    )
                    # 发送通知
                    if Config.NOTIFY_CONFIG['enable_wx']:
                        self.wx_notifier.notify_user_enter(
                            message.user.nick_name,
                            self.room_name
                        )
                        self._log_notification("进入直播间", f"用户 {message.user.nick_name} 进入直播间 {self.room_name}", message_id)
                    if Config.NOTIFY_CONFIG['enable_wework']:
                        self.wework_notifier.notify_user_enter(
                            message.user.nick_name,
                            self.room_name
                        )
                    
            elif method == 'WebcastGiftMessage':
                # 礼物消息
                message = GiftMessage().parse(payload)
                user_id = str(message.user.id)
                
                # 检查是否是监控的用户
                if user_id in Config.MONITOR_USERS:
                    self.logger.info(f"监控用户发送礼物 - 用户ID: {user_id}")
                    # 显示在控制台
                    self.console.show_user_gift(
                        message.user.nick_name,
                        self.room_name,
                        message.gift.name,
                        message.combo_count
                    )
                    # 发送通知
                    if Config.NOTIFY_CONFIG['enable_wx']:
                        self.wx_notifier.notify_user_gift(
                            message.user.nick_name,
                            self.room_name,
                            message.gift.name,
                            message.combo_count
                        )
                        self._log_notification("礼物消息", f"用户 {message.user.nick_name} 在直播间 {self.room_name} 发送礼物: {message.gift.name} x{message.combo_count}", message_id)
                    if Config.NOTIFY_CONFIG['enable_wework']:
                        self.wework_notifier.notify_user_gift(
                            message.user.nick_name,
                            self.room_name,
                            message.gift.name,
                            message.combo_count
                        )
                    
            elif method == 'WebcastControlMessage':
                # 直播间状态消息
                message = ControlMessage().parse(payload)
                if message.status == 3:
                    self.logger.info("直播间已结束")
                    self.console.show_info("直播间已结束")
                    self.live_fetcher.stop()
                    
            elif method == 'WebcastLinkMicMessage':
                # 连麦消息
                message = LinkMicMessage().parse(payload)
                user_id = str(message.user.id)
                
                # 检查是否是监控的用户
                if user_id in Config.MONITOR_USERS:
                    self.logger.info(f"监控用户发起连麦 - 用户ID: {user_id}")
                    # 显示在控制台
                    self.console.show_user_link(
                        message.user.nick_name,
                        self.room_name
                    )
                    # 发送通知
                    if Config.NOTIFY_CONFIG['enable_wx']:
                        self.wx_notifier.notify_user_link(
                            message.user.nick_name,
                            self.room_name
                        )
                        self._log_notification("连麦消息", f"用户 {message.user.nick_name} 在直播间 {self.room_name} 发起连麦", message_id)
                    if Config.NOTIFY_CONFIG['enable_wework']:
                        self.wework_notifier.notify_user_link(
                            message.user.nick_name,
                            self.room_name
                        )
                    
        except Exception as e:
            self.logger.error(f"处理{method}消息失败: {e}")
            self.console.show_error(f"处理{method}消息失败: {e}")
            
    def _get_room_name(self):
        """获取直播间名称"""
        try:
            # 从配置文件中获取直播间昵称
            if self.room_id in Config.ROOM_NAMES:
                room_name = Config.ROOM_NAMES[self.room_id]
                self.logger.info(f"从配置文件获取到直播间名称: {room_name}")
                return room_name
                
            # 如果配置文件中没有，尝试从直播间状态信息中获取
            room_status = self.live_fetcher.get_room_status()
            if room_status and hasattr(room_status, 'user') and hasattr(room_status.user, 'nick_name'):
                room_name = room_status.user.nick_name
                self.logger.info(f"从直播间状态获取到直播间名称: {room_name}")
                return room_name
                
        except Exception as e:
            self.logger.warning(f"获取直播间名称失败: {e}")
            
        return f'直播间 {self.room_id}'
        
    def _check_user_live_status(self):
        """检查用户开播状态"""
        try:
            # 只检查指定的直播间ID
            target_room_id = "909388516116"  # 这里替换为你要监控的直播间ID
            
            # 使用抖音直播API
            query_url = f"https://live.douyin.com/webcast/room/web/enter/?aid=6383&device_platform=web&browser_language=zh-CN&browser_platform=Win32&browser_name=Chrome&browser_version=109.0.0.0&web_rid={target_room_id}"
            
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
                "Accept": "application/json, text/plain, */*",
                "Accept-Language": "zh-CN,zh;q=0.9",
                "Accept-Encoding": "gzip, deflate",
                "Connection": "keep-alive",
                "Referer": f"https://live.douyin.com/{target_room_id}",
                "Cookie": "__ac_nonce=1234567890abcdef"  # 添加一个基本的Cookie
            }
            
            self.console.show_info(f"正在检查直播间 {target_room_id} 的状态...")
            response = self.session.get(query_url, headers=headers)
            
            if response.status_code == 200:
                try:
                    result = response.json()
                    
                    if result.get("status_code") == 0:
                        data = result.get("data")
                        if data:
                            room_datas = data.get('data')
                            if room_datas and len(room_datas) > 0:
                                room_data = room_datas[0]
                                room_status = data.get('room_status')
                                nickname = data.get('user', {}).get('nickname')
                                
                                # 检查直播状态变化
                                current_status = self.user_live_status.get(target_room_id)
                                
                                if current_status != room_status:
                                    self.user_live_status[target_room_id] = room_status
                                    
                                    if room_status == 0:  # 0表示正在直播
                                        room_title = room_data.get("title", "")
                                        room_cover_url = room_data.get("cover", {}).get("url_list", [None])[0]
                                        jump_url = f'https://live.douyin.com/{target_room_id}'
                                        
                                        # 显示在控制台
                                        self.console.show_live_start(
                                            nickname or f"用户{target_room_id}",
                                            target_room_id
                                        )
                                        
                                        # 发送开播通知
                                        try:
                                            if Config.NOTIFY_CONFIG['enable_wx']:
                                                self.wx_notifier.notify_user_live_start(
                                                    nickname or f"用户{target_room_id}",
                                                    target_room_id
                                                )
                                                self._log_notification("开播通知", f"用户 {nickname or f'用户{target_room_id}'} 开始直播", f"开播通知_{nickname or f'用户{target_room_id}'}_{target_room_id}")
                                            if Config.NOTIFY_CONFIG['enable_wework']:
                                                self.wework_notifier.notify_user_live_start(
                                                    nickname or f"用户{target_room_id}",
                                                    target_room_id
                                                )
                                        except Exception as e:
                                            self.console.show_error(f"发送通知失败: {e}")
                                    else:
                                        self.console.show_info(f"直播间 {target_room_id} 已下播")
                            else:
                                self.console.show_info("未找到直播间数据")
                        else:
                            self.console.show_info("API返回数据为空")
                    else:
                        self.console.show_error(f"API返回状态码不为0: {result.get('status_code')}")
                        
                except Exception as e:
                    self.console.show_error(f"解析直播间API响应失败: {e}")
            else:
                self.console.show_error(f"请求直播间API失败: {response.status_code}")
                
        except Exception as e:
            self.console.show_error(f"检查直播间状态失败: {e}")
            
    def start(self):
        """启动监控"""
        self.logger.info(f"开始监控直播间: {self.room_id}")
        
        while True:
            try:
                # 获取直播间信息
                self.live_fetcher.get_room_status()
                
                # 获取直播间名称
                self.room_name = self._get_room_name()
                
                # 启动WebSocket连接
                self.live_fetcher.start()
                
                # 定期检查用户开播状态
                while self.is_running:
                    self._check_user_live_status()
                    time.sleep(10)  # 每10秒检查一次
                    
                # 如果连接断开，等待一段时间后重试
                if not self.is_running:
                    time.sleep(Config.WS_RECONNECT_INTERVAL)
                    
            except Exception as e:
                self.logger.error(f"监控直播间失败: {e}")
                time.sleep(Config.WS_RECONNECT_INTERVAL)