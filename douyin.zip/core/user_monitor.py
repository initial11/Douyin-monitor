#!/usr/bin/python
# coding:utf-8

import time
import requests
import logging
from config.config import Config
from core.wx_notify import WxNotifier
from core.wework_notify import WeworkNotifier

class UserMonitor:
    def __init__(self):
        self.wx_notifier = WxNotifier()
        self.wework_notifier = WeworkNotifier()
        self.logger = logging.getLogger(__name__)
        self.live_status = {}  # 记录用户直播状态
        
    def _get_user_live_status(self, user_id):
        """获取用户直播状态"""
        try:
            # TODO: 实现获取用户直播状态的逻辑
            # 这里需要调用抖音API获取用户是否在直播
            return False
        except Exception as e:
            self.logger.error(f"获取用户直播状态失败: {e}")
            return None
            
    def start(self):
        """启动用户监控"""
        self.logger.info("开始监控用户直播状态")
        
        while True:
            try:
                for user_id in Config.MONITOR_USERS:
                    # 获取用户直播状态
                    is_live = self._get_user_live_status(user_id)
                    
                    # 检查状态变化
                    if user_id not in self.live_status:
                        self.live_status[user_id] = is_live
                    elif self.live_status[user_id] != is_live:
                        if is_live:
                            if Config.NOTIFY_CONFIG['enable_wx']:
                                self.wx_notifier.notify_user_live(user_id)
                            if Config.NOTIFY_CONFIG['enable_wework']:
                                self.wework_notifier.notify_user_live(user_id)
                        self.live_status[user_id] = is_live
                        
                # 等待一段时间后再次检查
                time.sleep(60)  # 每分钟检查一次
                
            except Exception as e:
                self.logger.error(f"监控用户直播状态失败: {e}")
                time.sleep(Config.WS_RECONNECT_INTERVAL) 