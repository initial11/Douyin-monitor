#!/usr/bin/python
# coding:utf-8

import json
import time
import logging
import requests
import qrcode
import os
from datetime import datetime
from config.config import Config

class WeiboNotifier:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.last_notify_time = {}  # 记录每种通知的最后发送时间
        self.cookies = None
        self.session = requests.Session()
        # 初始化时就尝试登录
        print("\n正在初始化微博通知...")
        if not self._login():
            print("微博登录失败，通知将不会发送到微博")
        
    def _login(self):
        """使用扫码方式登录微博"""
        try:
            # 获取登录二维码
            qr_url = "https://login.sina.com.cn/sso/qrcode/image"
            response = self.session.get(qr_url)
            if response.status_code == 200:
                result = response.json()
                if result.get('retcode') == 20000000:
                    # 直接使用返回的二维码数据
                    qr_data = result['data']['qrcode']
                    
                    # 生成二维码图片
                    qr = qrcode.QRCode(
                        version=1,
                        error_correction=qrcode.constants.ERROR_CORRECT_L,
                        box_size=10,
                        border=4,
                    )
                    qr.add_data(qr_data)
                    qr.make(fit=True)
                    qr_img = qr.make_image(fill_color="black", back_color="white")
                    
                    # 保存二维码图片到当前目录
                    qr_path = os.path.join(os.getcwd(), "weibo_qr.png")
                    qr_img.save(qr_path)
                    
                    # 打印二维码路径和提示信息
                    print("\n" + "="*50)
                    print("请使用微博APP扫描二维码登录")
                    print(f"二维码已保存到: {qr_path}")
                    print("扫码后请等待系统自动登录")
                    print("="*50 + "\n")
                    
                    # 轮询检查登录状态
                    qid = result['data']['qrid']
                    check_count = 0
                    while check_count < 30:  # 最多等待60秒
                        check_url = "https://login.sina.com.cn/sso/qrcode/check"
                        params = {
                            "entry": "weibo",
                            "qrid": qid,
                            "_": int(time.time() * 1000)
                        }
                        response = self.session.get(check_url, params=params)
                        if response.status_code == 200:
                            check_result = response.json()
                            if check_result.get('retcode') == 20000000:
                                if check_result['data'].get('alt') == '扫码成功':
                                    # 获取登录信息
                                    self.cookies = self.session.cookies.get_dict()
                                    print("微博登录成功！")
                                    return True
                            elif check_result.get('retcode') == 50114001:
                                print("二维码已过期，请重新运行程序")
                                return False
                        time.sleep(2)
                        check_count += 1
                    
                    print("登录超时，请重新运行程序")
                    return False
                        
        except Exception as e:
            self.logger.error(f"微博登录失败: {e}")
            print(f"微博登录失败: {e}")
            return False
            
    def _send_message(self, content):
        """发送微博消息"""
        try:
            if not self.cookies:
                if not self._login():
                    return False
                    
            url = "https://weibo.com/aj/mblog/add"
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                "Referer": "https://weibo.com/",
                "Origin": "https://weibo.com",
                "Content-Type": "application/x-www-form-urlencoded"
            }
            data = {
                "text": content,
                "sync_wb": 0,
                "api": "http://i.huati.weibo.com/pcpage/operation/publisher/sendMblog",
                "visible": 0,
                "isReEdit": False,
                "_t": 0
            }
            
            response = self.session.post(url, data=data, headers=headers)
            if response.status_code == 200:
                result = response.json()
                if result.get('code') == '100000':
                    return True
                else:
                    self.logger.error(f"发送微博消息失败: {result.get('msg')}")
            else:
                self.logger.error(f"发送微博消息请求失败: {response.status_code}")
                
        except Exception as e:
            self.logger.error(f"发送微博消息异常: {e}")
            
        return False
        
    def _check_notify_cooldown(self, event_type):
        """检查通知冷却时间"""
        current_time = time.time()
        if event_type in self.last_notify_time:
            if current_time - self.last_notify_time[event_type] < Config.NOTIFY_COOLDOWN:
                return False
        self.last_notify_time[event_type] = current_time
        return True
        
    def notify_user_message(self, nickname, room_name, content):
        """发送用户聊天消息通知"""
        if not self._check_notify_cooldown('message'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【弹幕提醒】\n【{nickname}】在【{room_name}】直播间发送了弹幕\n【弹幕内容:{content}】\n检测时间:{current_time}"
        
        self._send_message(message)
        
    def notify_user_enter(self, nickname, room_name):
        """发送用户进入直播间通知"""
        if not self._check_notify_cooldown('enter'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【提醒】\n检测到【{nickname}】进入了【{room_name}】直播间.\n检测时间:{current_time}"
        
        self._send_message(message)
        
    def notify_user_gift(self, nickname, room_name, gift_name, combo_count):
        """发送用户礼物通知"""
        if not self._check_notify_cooldown('gift'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【礼物检测】\n【{nickname}】在【{room_name}】直播间\n【送出了:{gift_name}】\n【检测时间:{current_time}】"
        
        self._send_message(message)
        
    def notify_user_live_start(self, nickname, live_id):
        """发送用户开播通知"""
        if not self._check_notify_cooldown('live_start'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【开播提醒】\n【{nickname}】开播了！\n直播间链接：https://live.douyin.com/{live_id}\n【检测时间:{current_time}】"
        
        self._send_message(message)
        
    def notify_user_link(self, user_name, room_name):
        """发送用户连麦通知"""
        if not self._check_notify_cooldown('link'):
            return
            
        current_time = datetime.now().strftime("%H时%M分%S秒")
        message = f"【连麦检测】\n【检测到【{user_name}】在【{room_name}】直播间连麦中...】\n【检测时间:{current_time}】"
        
        self._send_message(message) 