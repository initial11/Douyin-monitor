#!/usr/bin/python
# coding:utf-8

import logging
import time
import json
import requests
from datetime import datetime
from config.config import Config

class WeworkNotifier:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.last_notify_time = {}  # 记录每种通知的最后发送时间
        self.access_token = None
        self.token_expire_time = 0
        
    def _get_access_token(self):
        """获取企业微信访问令牌"""
        try:
            # 如果token未过期，直接返回
            if self.access_token and time.time() < self.token_expire_time:
                return self.access_token
                
            # 获取新的token
            url = f"https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={Config.WEWORK_CONFIG['corp_id']}&corpsecret={Config.WEWORK_CONFIG['secret']}"
            response = requests.get(url)
            result = response.json()
            
            if result.get('errcode') == 0:
                self.access_token = result.get('access_token')
                self.token_expire_time = time.time() + result.get('expires_in') - 200  # 提前200秒过期
                return self.access_token
            else:
                self.logger.error(f"获取企业微信token失败: {result}")
                return None
                
        except Exception as e:
            self.logger.error(f"获取企业微信token异常: {e}")
            return None
            
    def _check_notify_cooldown(self, event_type):
        """检查通知冷却时间"""
        current_time = time.time()
        if event_type in self.last_notify_time:
            if current_time - self.last_notify_time[event_type] < Config.NOTIFY_CONFIG['notify_cooldown']:
                return False
        self.last_notify_time[event_type] = current_time
        return True
        
    def _send_message(self, content):
        """发送企业微信消息"""
        try:
            access_token = self._get_access_token()
            if not access_token:
                return False
                
            url = f"https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={access_token}"
            data = {
                "touser": Config.WEWORK_CONFIG['to_user'],
                "msgtype": "text",
                "agentid": Config.WEWORK_CONFIG['agent_id'],
                "text": {
                    "content": content
                }
            }
            
            response = requests.post(url, json=data)
            result = response.json()
            
            if result.get('errcode') == 0:
                self.logger.debug("成功发送企业微信消息")
                return True
            else:
                self.logger.error(f"发送企业微信消息失败: {result}")
                return False
                
        except Exception as e:
            self.logger.error(f"发送企业微信消息异常: {e}")
            return False
            
    def notify_user_message(self, nickname, room_name, content):
        """发送用户聊天消息通知"""
        if not self._check_notify_cooldown('message'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【弹幕提醒】\n【{nickname}】在【{room_name}】直播间发送了弹幕\n【弹幕内容:{content}】\n检测时间:{current_time}"
        
        self._send_message(message)
        
    def notify_user_enter(self, nickname, room_name):
        """发送用户进入直播间通知"""
        if not self._check_notify_cooldown('enter'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【提醒】\n检测到【{nickname}】进入了【{room_name}】直播间.\n检测时间:{current_time}"
        
        self._send_message(message)
        
    def notify_user_gift(self, nickname, room_name, gift_name, combo_count):
        """发送用户礼物通知"""
        if not self._check_notify_cooldown('gift'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【礼物检测】\n【{nickname}】在【{room_name}】直播间\n【送出了:{gift_name}】\n【检测时间:{current_time}】"
        
        self._send_message(message)
        
    def notify_user_live_start(self, nickname, live_id):
        """发送用户开播通知"""
        if not self._check_notify_cooldown('live_start'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【开播提醒】\n【{nickname}】开播了！\n直播间链接：https://live.douyin.com/{live_id}\n【检测时间:{current_time}】"
        
        self._send_message(message)
        
    def notify_user_link(self, user_name, room_name):
        """发送用户连麦通知"""
        if not self._check_notify_cooldown('link'):
            return
            
        current_time = datetime.now().strftime("%H时%M分%S秒")
        message = f"【连麦检测】\n【检测到【{user_name}】在【{room_name}】直播间连麦中...】\n【检测时间:{current_time}】"
        
        self._send_message(message)
        
    def notify_user_live(self, user_name):
        """通知用户开播"""
        current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        content = f"【{user_name}】开始直播了\n开播时间:{current_time}"
        self._send_message(content) 