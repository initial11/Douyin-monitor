#!/usr/bin/python
# coding:utf-8

import logging
import time
import json
import requests
from datetime import datetime
from pywinauto.application import Application
from pywinauto.keyboard import send_keys
from config.config import Config
import pyperclip

class WxNotifier:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.last_notify_time = {}  # 记录每种通知的最后发送时间
        self.group_name = Config.WX_GROUP_NAME
        self.app = None
        self.main_window = None
        self._init_wx_window()
        
    def _init_wx_window(self):
        """初始化微信窗口"""
        try:
            # 连接到已经运行的微信
            self.app = Application(backend='uia').connect(title_re='.*微信.*')
            self.main_window = self.app.window(title_re='.*微信.*')
            
            if not self.main_window.exists():
                self.logger.error("未找到微信窗口，请确保微信已登录")
                return
                
            self.logger.info("成功找到微信窗口")
            
        except Exception as e:
            self.logger.error(f"初始化微信窗口失败: {e}")
            
    def _check_notify_cooldown(self, event_type):
        """检查通知冷却时间"""
        current_time = time.time()
        if event_type in self.last_notify_time:
            if current_time - self.last_notify_time[event_type] < Config.NOTIFY_CONFIG['notify_cooldown']:
                return False
        self.last_notify_time[event_type] = current_time
        return True
        
    def _send_message(self, content):
        """发送微信消息"""
        try:
            if not self.main_window or not self.main_window.exists():
                self.logger.error("微信窗口未找到，尝试重新初始化")
                self._init_wx_window()
                if not self.main_window or not self.main_window.exists():
                    return False
                    
            # 激活微信窗口
            self.main_window.set_focus()
            time.sleep(0.5)
            
            # 直接输入消息（使用剪贴板避免直接输入）
            pyperclip.copy(content)
            send_keys('^v')  # Ctrl+V 粘贴
            time.sleep(0.5)
            
            # 按回车发送
            send_keys('{ENTER}')
            
            self.logger.debug("成功发送微信消息")
            return True
                
        except Exception as e:
            self.logger.error(f"发送微信消息异常: {e}")
            return False
            
    def notify_user_message(self, nickname, room_name, content):
        """发送用户聊天消息通知"""
        if not self._check_notify_cooldown('message'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【弹幕提醒】\n{nickname}在{room_name}直播间发送了弹幕\n弹幕内容:{content}\n检测时间:{current_time}"
        
        self._send_message(message)
        
    def notify_user_enter(self, nickname, room_name):
        """发送用户进入直播间通知"""
        if not self._check_notify_cooldown('enter'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【提醒】\n检测到{nickname}进入了{room_name}直播间\n检测时间:{current_time}"
        
        self._send_message(message)
        
    def notify_user_gift(self, nickname, room_name, gift_name, combo_count):
        """发送用户礼物通知"""
        if not self._check_notify_cooldown('gift'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【礼物检测】\n{nickname}在{room_name}直播间\n送出了:{gift_name}\n检测时间:{current_time}"
        
        self._send_message(message)
        
    def notify_user_live_start(self, nickname, live_id):
        """发送用户开播通知"""
        if not self._check_notify_cooldown('live_start'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【开播提醒】\n{nickname}开播了！\n直播间链接：https://live.douyin.com/{live_id}\n检测时间:{current_time}"
        
        self._send_message(message)
        
    def notify_user_link(self, user_name, room_name):
        """发送用户连麦通知"""
        if not self._check_notify_cooldown('link'):
            return
            
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"【连麦检测】\n检测到{user_name}在{room_name}直播间连麦中...\n检测时间:{current_time}"
        
        self._send_message(message)
        
    def notify_user_live(self, user_name):
        """通知用户开播"""
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        content = f"【开播提醒】\n{user_name}开始直播了\n开播时间:{current_time}"
        self._send_message(content) 